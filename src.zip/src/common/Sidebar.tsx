import { NavLink } from 'react-router-dom';
import { HomeIcon, ChartBarIcon, PlusCircleIcon, UserGroupIcon, Cog6ToothIcon } from '@heroicons/react/24/outline';

const menuItems = [
  { path: '/', label: 'Dashboard', icon: HomeIcon },
  { path: '/create-bot', label: 'Create Bot', icon: PlusCircleIcon },
  { path: '/analytics', label: 'Analytics', icon: ChartBarIcon },
  { path: '/admin', label: 'Admin', icon: UserGroupIcon },
  { path: '/settings', label: 'Settings', icon: Cog6ToothIcon },
];

export default function Sidebar() {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const isAdmin = user.email === 'admin@bitforex.com'; // Change to your admin email

  return (
    <aside className="fixed top-0 left-0 h-full w-64 bg-card border-r border-border p-4">
      <div className="text-2xl font-bold text-accent mb-8">Bitforex</div>
      <nav className="space-y-2">
        {menuItems.map((item) => {
          if (item.label === 'Admin' && !isAdmin) return null;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-2 rounded-lg transition ${
                  isActive ? 'bg-accent/10 text-accent' : 'text-gray-400 hover:bg-border hover:text-white'
                }`
              }
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>
    </aside>
  );
}