import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Sidebar from '../components/common/Sidebar';
import PortfolioCard from '../components/dashboard/PortfolioCard';
import BotCard from '../components/dashboard/BotCard';
import PerformanceChart from '../components/dashboard/PerformanceChart';

export default function Dashboard() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const stored = localStorage.getItem('user');
    if (stored) setUser(JSON.parse(stored));
  }, []);

  return (
    <div className="flex min-h-screen bg-dark">
      <Sidebar />
      <main className="flex-1 p-6 ml-64">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white">Dashboard</h1>
            <p className="text-gray-400">Welcome back, {user?.firstName || 'Trader'}!</p>
          </div>
          <Link to="/create-bot" className="px-4 py-2 bg-accent text-dark font-semibold rounded-lg hover:opacity-80">
            + New Bot
          </Link>
        </div>

        {/* Portfolio */}
        <PortfolioCard value={12450.75} change={3.2} />

        {/* Performance Chart */}
        <div className="mt-6">
          <PerformanceChart />
        </div>

        {/* Active Bots */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <BotCard name="Bot #1" pair="BTC/USDT" strategy="AI Scaler" status="Running" profit={8.4} profitAmount={4200} />
          <BotCard name="Bot #2" pair="EUR/USD" strategy="Trend Follower" status="Paused" profit={2.1} profitAmount={750} />
          <BotCard name="Bot #3" pair="ETH/USDT" strategy="Grid Bot" status="Running" profit={5.1} profitAmount={1900} />
        </div>
      </main>
    </div>
  );
}